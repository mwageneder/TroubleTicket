package at.fh.swenga.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import at.fh.swenga.model.CommentModel;
import at.fh.swenga.model.TroubleTicketModel;

@Repository
@Transactional
public interface CommentRepository extends JpaRepository<CommentModel, Integer> {

	public CommentModel findById(int id);
	
	public List<CommentModel> findByTicket(TroubleTicketModel ticket);

}
