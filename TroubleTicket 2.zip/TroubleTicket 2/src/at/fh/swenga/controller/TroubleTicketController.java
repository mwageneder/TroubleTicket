package at.fh.swenga.controller;


import java.util.ArrayList;
import java.util.List;

import org.fluttercode.datafactory.impl.DataFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import at.fh.swenga.dao.CategoryRepository;
import at.fh.swenga.dao.CommentRepository;
import at.fh.swenga.dao.SupportRepository;
import at.fh.swenga.dao.TroubleTicketRepository;
import at.fh.swenga.dao.UserRepository;
import at.fh.swenga.model.TroubleTicketModel;

@Controller
@RequestMapping(value = "/troubleTicket")
public class TroubleTicketController {

	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	CommentRepository commentRepository;
	
	@Autowired
	SupportRepository supportRepository;
	
	@Autowired
	TroubleTicketRepository troubleTicketRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@RequestMapping(value = { "/", "list" }) // list TroubleTickets
	public String index(Model model) {
		List<TroubleTicketModel> troubleTickets = troubleTicketRepository.findAll();
		model.addAttribute("troubleTickets", troubleTickets);
		model.addAttribute("type", "findAll");
		return "tickets";
	}
	
	@RequestMapping(value = { "/getPage" })
	public String getPage(Pageable page, Model model) {

		Page<TroubleTicketModel> troubleTickets = troubleTicketRepository.findAll(page);
		model.addAttribute("troubleTickets", troubleTickets.getContent());
		model.addAttribute("troubleTicketPage", troubleTickets);

		return "troubleTicket/index";
	}
	
	@RequestMapping(value = { "/find" })
	public String find(Model model, @RequestParam String searchString, @ModelAttribute("type") String type) {
		List<TroubleTicketModel> troubleTickets = null;
		int count = 0;

		switch (type) {
		case "findAll":
			troubleTickets = troubleTicketRepository.findAll();
			break; // every Case needs it's Break !!!
		
			
		default:
			troubleTickets = troubleTicketRepository.findAll();
		}

		model.addAttribute("troubleTickets", troubleTickets);
		model.addAttribute("count", count);
		return "troubleTicket/index";
	}
	
	@RequestMapping(value = { "/findById" })
	public String findById(@RequestParam("id") TroubleTicketModel t, Model model) {

		List<TroubleTicketModel> troubleTickets = new ArrayList<TroubleTicketModel>();
		troubleTickets.add(t);
		model.addAttribute("troubleTickets", troubleTickets);
		return "troubleTicket/index";
	}

	@RequestMapping("/fill")
	@Transactional
	public String fillData(Model model) {

		DataFactory df = new DataFactory();

		for (int i = 0; i < 10; i++) {

			TroubleTicketModel ttm = new TroubleTicketModel(df.getRandomWord(10),df.getDate(2001, 1, 1),
					df.getDate(2002, 2, 2),
					df.getDate(2003, 3, 3),
					df.getRandomWord(5),
					df.getRandomWord(10)+""+df.getRandomWord(10),1);
			troubleTicketRepository.save(ttm);
		}

		return "forward:list";
	}
	@RequestMapping("/delete")
	public String deleteData(Model model, @RequestParam int id) {
		troubleTicketRepository.delete(id);

		return "forward:list";
	}
	
	
	@ExceptionHandler(Exception.class)
	public String handleAllException(Exception ex) {

		return "showError";
	}
	
}

