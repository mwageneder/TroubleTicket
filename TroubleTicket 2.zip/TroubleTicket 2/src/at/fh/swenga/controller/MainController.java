package at.fh.swenga.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.fluttercode.datafactory.impl.DataFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import at.fh.swenga.dao.CategoryRepository;
import at.fh.swenga.dao.CommentRepository;
import at.fh.swenga.dao.TroubleTicketRepository;
import at.fh.swenga.dao.UserRepository;
import at.fh.swenga.model.TroubleTicketModel;
import at.fh.swenga.model.UserModel;

@Controller
public class MainController {

	@Autowired
	CommentRepository commentRepository;

	@Autowired
	TroubleTicketRepository troubleTicketRepository;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	@RequestMapping(value = {"/", "login"})
	public String handleLogin(Model model) {
		return "login";
	}
	
	@RequestMapping(value = {"/signUp", "signUp"})
	public String signUp(Model model){
		return "signUp";
	}
	
	@RequestMapping(value = {"/createTicket", "addTicket"})
	public String createTicket(Model model){
		return "addTicket";
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public String showMain(Model model, @RequestParam String username, @RequestParam String password){
		
		UserModel user = userRepository.findByUsername(username);
		
		if(user == null){
			model.addAttribute("message", "Username or password incorrect!");
			return "login";
		}
		else{
			if(!user.getPassword().equals(password)){
				model.addAttribute("message", "Username or password incorrect!");
				return "login";
			}
		}
		
		List<TroubleTicketModel> troubleTickets = troubleTicketRepository.findAll();
		model.addAttribute("troubleTickets", troubleTickets);
		model.addAttribute("type", "findAll");
		
		model.addAttribute("user", username);
		return "supportDashboard";
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showMain(Model model){
		return "supportDashboard";
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUser(@Valid @ModelAttribute UserModel newUser, Model model) {
		
		UserModel user = userRepository.findByUsername(newUser.getUsername());
		
		if(user != null){
			model.addAttribute("message", "User already exists!");
		}
		else {
			newUser.setPicture("empty");
			userRepository.save(newUser);
			model.addAttribute("message", "New user added!");
		}
		return "login";
	}
	

	@RequestMapping(value = "/addTicket", method = RequestMethod.POST)
	public String addTicekt(@Valid @ModelAttribute TroubleTicketModel newTicket, Model model) {
		
		newTicket.setStatus("Open");
		troubleTicketRepository.save(newTicket);
		return "supportDashboard";
	}

	@ExceptionHandler(Exception.class)
	public String handleAllException(Exception ex) {

		return "showError";
	}
}
