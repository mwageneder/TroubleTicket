package at.fh.swenga.controller;

import java.util.ArrayList;
import java.util.List;

import org.fluttercode.datafactory.impl.DataFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import at.fh.swenga.dao.CommentRepository;
import at.fh.swenga.dao.TroubleTicketRepository;
import at.fh.swenga.dao.UserRepository;
import at.fh.swenga.model.UserModel;

@Controller
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	CommentRepository commentRepository;

	@Autowired
	TroubleTicketRepository troubleTicketRepository;

	@Autowired
	UserRepository userRepository;
	

	@RequestMapping(value = { "/", "list" })
	public String index(Model model) {
		List<UserModel> users = userRepository.findAll();
		model.addAttribute("users", users);
		model.addAttribute("type", "findAll");
		return "index";
	}


	@RequestMapping(value = { "/getPage" })
	public String getPage(Pageable page, Model model) {

		Page<UserModel> users = userRepository.findAll(page);
		model.addAttribute("users", users.getContent());
		model.addAttribute("usersPage", users);

		return "index";
	}

	@RequestMapping(value = { "/find" })
	public String find(Model model, @RequestParam String searchString, @ModelAttribute("type") String type) {
		List<UserModel> users = null;
		int count = 0;

		switch (type) {
		case "findAll":
			users = userRepository.findAll();
			break;
		case "findByFirstName":
			users = userRepository.findByFirstName(searchString);
			break;

		default:
			users = userRepository.findAll();
		}

		model.addAttribute("users", users);
		model.addAttribute("count", count);
		return "index";
	}

	@RequestMapping(value = { "/findById" })
	public String findById(@RequestParam("id") UserModel e, Model model) {

		List<UserModel> users = new ArrayList<>();
		users.add(e);
		model.addAttribute("users", users);
		return "index";
	}

	@RequestMapping("/fill")
	@Transactional
	public String fillData(Model model) {

		DataFactory df = new DataFactory();

		for (int i = 0; i < 10; i++) {

			UserModel um = new UserModel(df.getFirstName(), df.getLastName(), df.getRandomWord(8), df.getEmailAddress(),
					df.getRandomWord(10), df.getRandomWord(10));
			userRepository.save(um);

		}

		return "forward:list";
	}

	@RequestMapping("/delete")
	public String deleteData(Model model, @RequestParam int id) {
		userRepository.delete(id);

		return "forward:list";
	}

	@ExceptionHandler(Exception.class)
	public String handleAllException(Exception ex) {

		return "showError";

	}

}
