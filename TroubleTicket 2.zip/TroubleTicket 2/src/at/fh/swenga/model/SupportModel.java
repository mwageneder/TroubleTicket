package at.fh.swenga.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "Support")
public class SupportModel extends UserModel {

	//@Id
	//@Column(name = "id")
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//private int id;

	@ManyToMany(cascade = CascadeType.PERSIST)
	private List<CategoryModel> categories;

	//@Version
	//long version;

	public SupportModel() {

	}

	public SupportModel(int id, String firstname, String lastname, String username, String email, String password,
			String picture) {
		super(firstname, lastname, username, email, password, picture);
	}

	public List<CategoryModel> getCategories() {
		return categories;
	}

	public void setCategories(List<CategoryModel> categories) {
		this.categories = categories;
	}

	public void addCategory(CategoryModel category) {
		if (categories == null) {
			categories = new ArrayList<CategoryModel>();
		}
		categories.add(category);
	}
}
