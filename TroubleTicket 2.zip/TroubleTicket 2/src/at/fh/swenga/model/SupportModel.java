package at.fh.swenga.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "support")
public class SupportModel extends UserModel {

	//other table
	@OneToMany(mappedBy="support",fetch=FetchType.LAZY)
	private Set<CategoryModel> categories;

	public SupportModel() {

	}

	public SupportModel(int id, String firstname, String lastname, String username, String email, String password,
			String picture) {
		super(firstname, lastname, username, email, password, picture);
	}

	public Set<CategoryModel> getCategories() {
		return categories;
	}

	public void setCategories(Set<CategoryModel> categories) {
		this.categories = categories;
	}
	
	public void addCategory(CategoryModel category) {
		if (categories == null) {
			categories = new HashSet<CategoryModel>();
		}
		categories.add(category);
	}
}
